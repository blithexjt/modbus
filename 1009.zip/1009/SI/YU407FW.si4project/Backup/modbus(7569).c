/*******************************************************************************
 * (c) Copyright 2013, Foxtone Inc., Shenzhen
 * File:        modbus.c
 * Describe:
 * Author:      LiangXiJie
 * Date:        2013-2-26
 *******************************************************************************/
#include "modbus.h"
#include "motor.h"


#define LOBYTE(x)	((unsigned char)(x))
#define HIBYTE(x)	(((unsigned short)(x))>>8)
#define FILL_VAL(buf,val)	buf[0]=HIBYTE(val);buf[1]=LOBYTE(val)

unsigned char GetRegs(unsigned short addr,unsigned short count,unsigned char *buff);
unsigned char SetReg(unsigned short addr,unsigned short count,unsigned char *buff);

/******************************************************************************
 * Function: Modbus
 * Describe: 
 ******************************************************************************/
void Modbus(unsigned char *buff, unsigned char *len)
{
	ADU_REQ *pRequest = (ADU_REQ*)buff;
	ADU_REQ_S *pRequestS = (ADU_REQ_S*)buff;
	ADU_RES *pResponse = (ADU_RES*)buff;
	ADU_ERR *pError = (ADU_ERR*)buff;
	unsigned short addr;
	unsigned short val;
	unsigned char err;
	unsigned char val_buf[2];

	if(*len != sizeof(ADU_REQ)) pError->func |= 0x80;

	switch(pRequest->func)
	{
		case 0x03:
		case 0x04:
			addr = pRequest->addr_hi;
			addr *= 256;
			addr += pRequest->addr;
			val = pRequest->count;
			err = GetRegs(addr,val,pResponse->data);
			if(!err){
				pResponse->bytecount = val * 2;
				pResponse->mbap.len = 3+pResponse->bytecount;
				*len = pResponse->bytecount + 1 + 1 + sizeof(MBAP);
			}else{
				pError->func |= 0x80;
				pError->code = err;
				*len = 1 + 1 + sizeof(MBAP);
			}
			break;

		case 0x06:
			addr = pRequest->addr_hi;
			addr *= 256;
			addr += pRequest->addr;
			val_buf[0] = pRequest->count_hi;
			val_buf[1] = pRequest->count;
			err = SetReg(addr,1,val_buf);
			if(!err){
				//return back;
			}else{
				pError->func |= 0x80;
				pError->code = err;
				*len = 1 + 1 + sizeof(MBAP);
			}
			break;
		case 0x10:
			addr = pRequestS->addr_hi;
			addr *= 256;
			addr += pRequestS->addr;
			val = pRequestS->count;
			err = SetReg(addr,val,pRequestS->data);
			if(!err){
				pRequest->mbap.len = 0x0006;
				*len = sizeof(ADU_REQ);
			}else{
				pError->func |= 0x80;
				pError->code = err;
				*len = 1 + 1 + sizeof(MBAP);
			}
			break;
		default:
			pError->func |= 0x80;
			pError->code = 1;
			*len = 1 + 1 + sizeof(MBAP);
			break;
	}
}

/******************************************************************************
 * Function: GetRegs
 * Describe: 
 ******************************************************************************/
unsigned char GetRegs(unsigned short addr,unsigned short count,unsigned char *buff)
{
	unsigned short i;
	//unsigned short k;
	for(i = 0; i < count; i++)
	{
		switch(addr)
		{
			case 0x1000:
				FILL_VAL(buff, addr);
				break;
			case 0x2000:
				FILL_VAL(buff, addr);
				break;
			default:
				FILL_VAL(buff, addr+1);
				break;
		}
		addr ++;
		buff += 2;
	}
	return 0;
}

/******************************************************************************
 * Function: SetRegs
 * Describe: 
 ******************************************************************************/
unsigned char SetReg(unsigned short addr,unsigned short count,unsigned char *buff)
{
	unsigned short i;
	static int speed = 0;
	static short cur = 0;
	static int length = 0;
	static short state = 0;
	unsigned char mode = 0;
	for(i = 0; i < count; i++)
	{
		switch(addr)
		{
			case 0x1000:
				state = (*buff);
				state = (state<<8) + (*(buff+1));
				if(count == 1){
					if(state == 1)
						MotorStart( Motor_x, (u8)cur);	
					else if(state == 0)
						MotorStop( Motor_x, (u8)cur);	
					return 0;
				}
				else
				{
					mode = 0x80;
				}
				break;
			case 0x1001:
				cur = (*buff);
				cur = (cur<<8) + (*(buff+1));
				//MotorSetCurrent( Motor_x,  (u8)pdBuffer[0] );
				mode |= 0x01;
				break;
			case 0x1002:
				speed = (*buff);
				speed = (speed<<8) + (*(buff+1));
				speed = (speed<<8) + (*(buff+2));
				speed = (speed<<8) + (*(buff+3));
				//MotorSetSpeed( Motor_x,  pdBuffer[0]);
				mode |= 0x02;
				addr ++;
				buff += 2;	
				i++;
				break;
			case 0x1004:
				length = (*buff);
				length = (length<<8) + (*(buff+1));
				length = (length<<8) + (*(buff+2));
				length = (length<<8) + (*(buff+3));
				//MotorRun( Motor_x,  (u8) pdBuffer[0],pdBuffer[1], pdBuffer[2]);
				mode |= 0x04;
				addr ++;
				buff += 2;
				i++;
				break;
			default:
				return 2;
		}
		addr ++;
		buff += 2;
	}
	if((mode&&0x0F) == 0x01)
	{
		MotorSetCurrent( Motor_x,  cur );
	}
	else if((mode&&0x0F) == 0x02)
	{
		MotorSetSpeed( Motor_x,  speed);
	}
	else if((mode&&0x0F) == 0x03)
	{
		MotorSetCurrent( Motor_x,  cur );
		MotorSetSpeed( Motor_x,  speed);
	}
	else if((mode&&0x0F) == 0x07)
	{
		MotorRun( Motor_x,  (u8) cur,speed, length);
	}

	if(mode&&0x80)
	{
		if(state == 1)
			MotorStart( Motor_x, (u8)cur);	
		else if(state == 0)
			MotorStop( Motor_x, (u8)cur);	
	}
	return 0;
}


/*******************************************************************************
 *                                End of File
 *******************************************************************************/

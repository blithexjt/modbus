/*******************************************************************************
 * (c) Copyright 2013, Foxtone Inc., Shenzhen
 * File:        modbus.c
 * Describe:
 * Author:      LiangXiJie
 * Date:        2013-2-26
 *******************************************************************************/
#include "modbus.h"
#include "motor.h"
#include "ucommand.h"


static int speed = 0;
static short cur = 0;
static int length = 0;
static short state = 0;

extern union DealDataFloat2Byte_TypeDef DealDataBufferUnion[M812X_CHN_NUMBER];
extern double m_dEngValue[M812X_CHN_NUMBER];
extern Force_num f1;

#define LOBYTE(x)	((unsigned char)(x))
#define HIBYTE(x)	(((unsigned short)(x))>>8)
#define FILL_VAL(buf,val)	buf[0]=HIBYTE(val);buf[1]=LOBYTE(val)

unsigned char GetRegs(unsigned short addr,unsigned short count,unsigned char *buff);
unsigned char SetReg(unsigned short addr,unsigned short count,unsigned char *buff);

float HoldReg_Write4Byte(unsigned char* databuff);

/******************************************************************************
 * Function: Modbus
 * Describe: 
 ******************************************************************************/
void Modbus(unsigned char *buff, unsigned char *len)
{
	ADU_REQ *pRequest = (ADU_REQ*)buff;
	ADU_REQ_S *pRequestS = (ADU_REQ_S*)buff;
	ADU_RES *pResponse = (ADU_RES*)buff;
	ADU_ERR *pError = (ADU_ERR*)buff;
	unsigned short addr;
	unsigned short val;
	unsigned char err;
	unsigned char val_buf[2];

	//if(*len != sizeof(ADU_REQ)) pError->func |= 0x80;

	switch(pRequest->func)
	{
		case 0x03:
		case 0x04:
			addr = pRequest->addr_hi;
			addr *= 256;
			addr += pRequest->addr;
			val = pRequest->count;
			err = GetRegs(addr,val,pResponse->data);
			if(!err){
				pResponse->bytecount = val * 2;
				pResponse->mbap.len = 3+pResponse->bytecount;
				*len = pResponse->bytecount + 1 + 1 + sizeof(MBAP);
			}else{
				pError->func |= 0x80;
				pError->code = err;
				*len = 1 + 1 + sizeof(MBAP);
			}
			break;

		case 0x06:
			addr = pRequest->addr_hi;
			addr *= 256;
			addr += pRequest->addr;
			val_buf[0] = pRequest->count_hi;
			val_buf[1] = pRequest->count;
			err = SetReg(addr,1,val_buf);
			if(!err){
				//return back;
			}else{
				pError->func |= 0x80;
				pError->code = err;
				*len = 1 + 1 + sizeof(MBAP);
			}
			break;
		case 0x10:
			addr = pRequestS->addr_hi;
			addr *= 256;
			addr += pRequestS->addr;
			val = pRequestS->count;
			err = SetReg(addr,val,pRequestS->data);
			if(!err){
				pRequest->mbap.len = 0x06;
				*len = sizeof(ADU_REQ);
			}else{
				pError->func |= 0x80;
				pError->code = err;
				*len = 1 + 1 + sizeof(MBAP);
			}
			break;
		default:
			pError->func |= 0x80;
			pError->code = 1;
			*len = 1 + 1 + sizeof(MBAP);
			break;
	}
}

/******************************************************************************
 * Function: GetRegs
 * Describe: 
 ******************************************************************************/
unsigned char GetRegs(unsigned short addr,unsigned short count,unsigned char *buff)
{
	unsigned short i;
	unsigned short j;

	//unsigned short k;
	for(i = 0; i < count; i++)
	{
		switch(addr)
		{
			case 0x0100:
				FILL_VAL(buff, motor1_data.state);
				break;
			case 0x0101:
				FILL_VAL(buff, motor1_data.current);
				break;
			case 0x0102:
				FILL_VAL(buff, (unsigned short)(motor1_data.speed>>16));
				break;
			case 0x0103:
				FILL_VAL(buff, motor1_data.speed);
				break;
			case 0x0104:
				FILL_VAL(buff, (unsigned short)(motor1_data.length>>16));
				break;
			case 0x0105:
				FILL_VAL(buff, motor1_data.length);
				break;
			case Reg_Get_Mlenth_Cur_X:
				FILL_VAL(buff, motor1_data.length_cur);
				buff += 2;
				FILL_VAL(buff, (unsigned short)(motor1_data.length_cur>>16));
				addr ++;
				break;	
			
			case 0x1000:
				FILL_VAL(buff, motor2_data.state);
				break;
			case 0x1001:
				FILL_VAL(buff, motor2_data.current);
				break;
			case 0x1002:
				FILL_VAL(buff, (unsigned short)(motor2_data.speed>>16));
				break;
			case 0x1003:
				FILL_VAL(buff, motor2_data.speed);
				break;
			case 0x1004:
				FILL_VAL(buff, (unsigned short)(motor2_data.length>>16));
				break;
			case 0x1005:
				FILL_VAL(buff, motor2_data.length);
				break;
			case Reg_Get_Mlenth_Cur_Y:
				FILL_VAL(buff, motor2_data.length_cur);
				buff += 2;
				FILL_VAL(buff, (unsigned short)(motor2_data.length_cur>>16));
				addr ++;
				break;	
			
			case Reg_Get_Force_X:
//				f1.F_X.f_data = 12.2;
				for(j=0;j<4;j++)
				{
					buff[j] = f1.F_X.uc_data[j];
				}
				addr ++;
				buff += 2;
				break;
			case Reg_Get_Force_Y:
				for(j=0;j<4;j++)
				{
					buff[j] = f1.F_Y.uc_data[j];
				}				
				addr ++;
				buff += 2;
				break;
			case Reg_Get_Force_Z:
				for(j=0;j<4;j++)
				{
					buff[j] = f1.F_Z.uc_data[j];
				}				
				addr ++;
				buff += 2;
				break;
			case 0x3000:
				FILL_VAL(buff, addr);
				break;
			default:
				FILL_VAL(buff, addr+1);
				break;
		}
		addr ++;
		buff += 2;
	}
	return 0;
}

/******************************************************************************
 * Function: SetRegs
 * Describe: 
 ******************************************************************************/
unsigned char SetReg(unsigned short addr,unsigned short count,unsigned char *buff)
{
	unsigned short i;

	unsigned char mode = 0;
	for(i = 0; i < count; i++)
	{
		switch(addr)
		{
			case Reg_Set_Mstart_X:
				motor1_data.state = (*buff);
				motor1_data.state = (motor1_data.state<<8) + (*(buff+1));

				motor1_data.deal_mode = 0x80;
				break;
			case Reg_Set_Mcurrent_X:
				motor1_data.current = (*buff);
				motor1_data.current = (motor1_data.current<<8) + (*(buff+1));

				motor1_data.deal_mode |= 0x01;
				break;
			case Reg_Set_Mspeed_X:
				motor1_data.speed = (*buff);
				motor1_data.speed = (motor1_data.speed<<8) + (*(buff+1));
				motor1_data.speed = (motor1_data.speed<<8) + (*(buff+2));
				motor1_data.speed = (motor1_data.speed<<8) + (*(buff+3));
				//MotorSetSpeed( Motor_x,  pdBuffer[0]);
				motor1_data.deal_mode |= 0x02;
				addr ++;
				buff += 2;	
				i++;
				break;
			case Reg_Set_Mlenth_X:
				motor1_data.length = (*buff);
				motor1_data.length = (motor1_data.length<<8) + (*(buff+1));
				motor1_data.length = (motor1_data.length<<8) + (*(buff+2));
				motor1_data.length = (motor1_data.length<<8) + (*(buff+3));
				//MotorRun( Motor_x,  (u8) pdBuffer[0],pdBuffer[1], pdBuffer[2]);
				motor1_data.deal_mode |= 0x04;
				addr ++;
				buff += 2;
				i++;
				break;
			case Reg_Set_Mstart_Y:
				motor2_data.state = (*buff);
				motor2_data.state = (motor2_data.state<<8) + (*(buff+1));
				motor2_data.deal_mode = 0x80;
				break;
			case Reg_Set_Mcurrent_Y:
				motor2_data.current = (*buff);
				motor2_data.current = (motor2_data.current<<8) + (*(buff+1));

				motor2_data.deal_mode |= 0x01;
				break;
			case Reg_Set_Mspeed_Y:
				motor2_data.speed = (*buff);
				motor2_data.speed = (motor2_data.speed<<8) + (*(buff+1));
				motor2_data.speed = (motor2_data.speed<<8) + (*(buff+2));
				motor2_data.speed = (motor2_data.speed<<8) + (*(buff+3));

				motor2_data.deal_mode |= 0x02;
				addr ++;
				buff += 2;	
				i++;
				break;
			case Reg_Set_Mlenth_Y:
				motor2_data.length = (*buff);
				motor2_data.length = (motor2_data.length<<8) + (*(buff+1));
				motor2_data.length = (motor2_data.length<<8) + (*(buff+2));
				motor2_data.length = (motor2_data.length<<8) + (*(buff+3));

				motor2_data.deal_mode |= 0x04;
				addr ++;
				buff += 2;
				i++;
				break;
//			case Reg_Set_Force_X:
//				//f1.F_X  = *((float*) buff);
//				f1.F_X  = HoldReg_Write4Byte(buff);
//				addr ++;
//				buff += 2;
//				i++;
//				break;
//			case Reg_Set_Force_Y:
//				//f1.F_Y  =  (*buff);
//				//f1.F_Y  = (f1.F_Y<<8) + (*(buff+1));
//				//f1.F_Y  = (f1.F_Y<<8) + (*(buff+2));
//				//f1.F_Y  = (f1.F_Y<<8) + (*(buff+3));
//				f1.F_Y  = HoldReg_Write4Byte(buff);
//				addr ++;
//				buff += 2;
//				i++;
//				break;
//			case Reg_Set_Force_Z:
//				//f1.F_Z=  (*buff);
//				//f1.F_Z  = (f1.F_Z<<8) + (*(buff+1));
//				//f1.F_Z  = (f1.F_Z<<8) + (*(buff+2));
//				//f1.F_Z  = (f1.F_Z<<8) + (*(buff+3));
//				f1.F_Z  = HoldReg_Write4Byte(buff);
//				addr ++;
//				buff += 2;
//				i++;
//				break;
			default:
				return 2;
		}
		addr ++;
		buff += 2;
	}

	return 0;
}


float HoldReg_Write4Byte(unsigned char* databuff)
{
	float_DtformConver Data;
	float temp;
	Data.uc_Buf[0]= databuff[0];
	Data.uc_Buf[1]= databuff[1];
	Data.uc_Buf[2]= databuff[2];
	Data.uc_Buf[3]= databuff[3];
	temp = Data.f_Buf;
	return temp;
}

/*******************************************************************************
 *                                End of File
 *******************************************************************************/

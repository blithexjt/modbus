/*******************************************************************************
 * (c) Copyright 2013, Foxtone Inc., Shenzhen
 * File:        modbus.h
 * Describe:
 * Author:      LiangXiJie
 * Date:        2020/1/7
 *******************************************************************************/
#ifndef _MODBUS_H_
#define _MODBUS_H_

typedef enum
{
	Reg_Set_Mstart_X = 0x0100,
	Reg_Set_Mcurrent_X ,
	Reg_Set_Mspeed_X,
	Reg_Set_Mlenth_X= 0x0104,
	Reg_Set_Mstart_Y = 0x1000,
	Reg_Set_Mcurrent_Y,
	Reg_Set_Mspeed_Y,
	Reg_Set_Mlenth_Y = 0x1004,
	Reg_Set_Force_X = 0x2000,
	Reg_Set_Force_Y = 0x2002,
	Reg_Set_Force_Z = 0x2004,
}REG_SET;
typedef enum
{
	Reg_Get_Mlenth_Cur_X = 0x0006,
	Reg_Get_Mlenth_Cur_Y = 0x1006,
	Reg_Get_Force_X = 0x2006,
	Reg_Get_Force_Y = 0x2008,
	Reg_Get_Force_Z = 0x2010,
}REG_GET;
typedef struct
{
	unsigned char id_hi;
	unsigned char id_lo;
	unsigned char pro_hi;
	unsigned char pro_lo;
	unsigned char len_hi;
	unsigned char len;
	unsigned char slave;
}MBAP;

typedef struct
{
	MBAP			mbap;
	unsigned char	func;
	unsigned char	addr_hi;
	unsigned char	addr;
	unsigned char	count_hi;
	unsigned char	count;
}ADU_REQ;

typedef struct
{
	MBAP			mbap;
	unsigned char	func;
	unsigned char	bytecount;
	unsigned char	data[256];
}ADU_RES;


typedef struct
{
	MBAP			mbap;
	unsigned char	func;
	unsigned char	addr_hi;
	unsigned char	addr;
	unsigned char	count_hi;
	unsigned char	count;
	unsigned char	byte_count;
	unsigned char	data[256];
}ADU_REQ_S;

typedef struct
{
	MBAP			mbap;
	unsigned char	func;
	unsigned char	code;
}ADU_ERR;

typedef union                                        
{
	float f_Buf;  //D?��y
	unsigned char uc_Buf[4];  //u8��?��?������?��?IEEE754����D����?D?��y
	unsigned short us_Buf[2];  //u16��?��?����??IEEE754����D����?D?��y��?��?��?����3???��??��?D
	unsigned int u_Buf;
}float_DtformConver; 

void Modbus(unsigned char *buff, unsigned char *len);


#endif//_MODBUS_H_
/*******************************************************************************
 *                                End of File
 *******************************************************************************/

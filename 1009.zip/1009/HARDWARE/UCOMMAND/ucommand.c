#include "ucommand.h"
#include <string.h>
#include <stdio.h>
#include "force.h"
#include "usart.h"
#include "delay.h"


MOTOR_DATA motor1_data;
MOTOR_DATA motor2_data;


const double Current[16] = {100,93.75,87.5,81.25,75,68.75,62.5,56.25,50,43.75,37.5,31.25,25,18.75,12.5,6.25};
static u8 *rxbuf ;
u8 CheckModbusCommand()
{
	if(motor1_data.deal_mode)
	{
		if(motor1_data.deal_mode&0x80)
		{
			if(motor1_data.state == 1)
				MotorStart( Motor_x, (u8)motor1_data.current);	
			else if(motor2_data.state == 0)
				MotorStop( Motor_x, (u8)motor1_data.current);	
		}
		if((motor1_data.deal_mode&0x0F) == 0x01)
		{
			MotorSetCurrent( Motor_x,  motor1_data.current );
		}
		else if((motor1_data.deal_mode&0x0F) == 0x02)
		{
			MotorSetSpeed( Motor_x,  motor1_data.speed);
		}
		else if((motor1_data.deal_mode&0x0F) == 0x03)
		{
			MotorSetCurrent( Motor_x,  motor1_data.current );
			MotorSetSpeed( Motor_x,  motor1_data.speed);
		}
		else if((motor1_data.deal_mode&0x0F) == 0x07)
		{
			MotorRun( Motor_x,  (u8) motor1_data.current,motor1_data.speed, motor1_data.length);
		}
		motor1_data.deal_mode = 0;

	}
	if(motor2_data.deal_mode)
	{
		if(motor2_data.deal_mode&0x80)
		{
			if(motor2_data.state == 1)
				MotorStart( Motor_y, (u8)motor2_data.current);	
			else if(motor2_data.state == 0)
				MotorStop( Motor_y, (u8)motor2_data.current);	
		}
		if((motor2_data.deal_mode&0x0F) == 0x01)
		{
			MotorSetCurrent( Motor_y,  motor2_data.current );
		}
		else if((motor2_data.deal_mode&0x0F) == 0x02)
		{
			MotorSetSpeed( Motor_y,  motor2_data.speed);
		}
		else if((motor2_data.deal_mode&0x0F) == 0x03)
		{
			MotorSetCurrent( Motor_y,  motor2_data.current );
			MotorSetSpeed( Motor_y,  motor2_data.speed);
		}
		else if((motor2_data.deal_mode&0x0F) == 0x07)
		{
			MotorRun( Motor_y,  (u8) motor2_data.current,motor2_data.speed, motor2_data.length);
		}
		motor2_data.deal_mode = 0;
	}
}

u8 CheckUartCommand()
{
	u8 i = 0;
	UART1_Receive* uartStruct;
	double pdBuffer[3] ={0};

	for(i = 0;i<Uart1Array_Len;i++)
	{
		uartStruct = GetUart1Buffer(i);
		if(uartStruct->DataSta == UartData_Vaild)
		{
			//clear the USART1 DataSta flag
			uartStruct->DataSta = UartData_None;
			rxbuf = uartStruct->com1_rx_buffer;
			if(strstr((char*)rxbuf,"MOTORX-C:"))
			{
				GetUartParameter("MOTORX-C:",pdBuffer,1);
				printf("MOTORX-C:RECEIVE:%f\r\n",Current[(u8) pdBuffer[0]]);
				MotorSetCurrent( Motor_x,  (u8)pdBuffer[0] );
				return 1;
			}
			else if(strstr((char*)rxbuf,"MOTORX-S:"))
			{
				GetUartParameter("MOTORX-S:",pdBuffer,1);
				printf("MOTORX-S:RECEIVE:%fmm/s\r\n",pdBuffer[0]);
				MotorSetSpeed( Motor_x,  pdBuffer[0]);
				return 1;
			}
			else if(strstr((char*)rxbuf,"MOTORX-START:"))
			{
				GetUartParameter("MOTORX-START:",pdBuffer,1);
				printf("MOTORX-START:RECEIVE:%f\r\n",Current[(u8) pdBuffer[0]]);
				MotorStart( Motor_x, (u8)pdBuffer[0]);			 
				 return 1;
			}
			else if(strstr((char*)rxbuf,"MOTORX-STOP:"))
			{
				GetUartParameter("MOTORX-STOP:",pdBuffer,1);
				printf("MOTORX-STOP:RECEIVE:%f\r\n",Current[(u8) pdBuffer[0]]);
				MotorStop( Motor_x, (u8)pdBuffer[0]);
				return MOTORX_Stop;

			}
			else if(strstr((char*)rxbuf,"MOTORX-RUN:"))
			{
				GetUartParameter("MOTORX-RUN:",pdBuffer,3);
				printf("MOTORX-RUN:RECEIVE:%f,%f mm/s,%f mm\r\n",Current[(u8) pdBuffer[0]],pdBuffer[1],pdBuffer[2]);
				MotorRun( Motor_x,  (u8) pdBuffer[0],pdBuffer[1], pdBuffer[2]);
				return MOTORX_Run;
			}
			else if(strstr((char*)rxbuf,"MOTORY-C:"))
			{
				GetUartParameter("MOTORY-C:",pdBuffer,1);
				printf("MOTORY-C:RECEIVE:%f\r\n",Current[(u8) pdBuffer[0]]);
				MotorSetCurrent( Motor_y,  (u8)pdBuffer[0] );
				return MOTORY_Current;
			}
			else if(strstr((char*)rxbuf,"MOTORY-S:"))
			{
				GetUartParameter("MOTORY-S:",pdBuffer,1);
				printf("MOTORY-S:RECEIVE:%fmm/s\r\n",pdBuffer[0]);
				MotorSetSpeed( Motor_y,  pdBuffer[0]);
				return MOTORY_Speed;
			}
			else if(strstr((char*)rxbuf,"MOTORY-START:"))
			{
				GetUartParameter("MOTORY-START:",pdBuffer,1);
				printf("MOTORY-START:RECEIVE:%f\r\n",Current[(u8) pdBuffer[0]]);
				MotorStart( Motor_y, (u8)pdBuffer[0]);			 
				 return MOTORY_Start;
			}
			else if(strstr((char*)rxbuf,"MOTORY-STOP:"))
			{
				GetUartParameter("MOTORY-STOP:",pdBuffer,1);
				printf("MOTORY-STOP:RECEIVE:%f\r\n",Current[(u8) pdBuffer[0]]);
				MotorStop( Motor_y, (u8)pdBuffer[0]);
				return MOTORY_Stop;

			}
			else if(strstr((char*)rxbuf,"MOTORY-RUN:"))
			{
				GetUartParameter("MOTORY-RUN:",pdBuffer,3);
				printf("MOTORY-RUN:RECEIVE:%f,%f mm/s,%f mm\r\n",Current[(u8) pdBuffer[0]],pdBuffer[1],pdBuffer[2]);
				MotorRun( Motor_y,   pdBuffer[0],pdBuffer[1], pdBuffer[2]);
				return MOTORY_Run;
			}
			else  return 0;
		}
	}
	return 0;
}

u8 GetUartParameter(char *pInstr,double *pdBuffe,u8 ParametNum)
{
	char *pIndexBuffer = NULL;
	char CharTemp[16];
	double pdTemp[5];
	
	int k = 0x00;
	int i = 0x00;
	double dTemp = 0.0;
	long int len = strlen(pInstr);
	pIndexBuffer = strstr((char*)rxbuf,pInstr);
	if(pIndexBuffer == NULL) return false;

	pIndexBuffer = pIndexBuffer+len;

	for( i = 0; i < ParametNum; i++)
	{
		memset(CharTemp,0x00,16);		
		k = 0x00;
		while(*pIndexBuffer != ';' && *pIndexBuffer != '\r'&&*pIndexBuffer != '\n')
		{
			if(((*pIndexBuffer >= 0x30)&&(*pIndexBuffer <= 0x39))||(*pIndexBuffer == '.')||(*pIndexBuffer == '-'))
				CharTemp[k++] = *pIndexBuffer++;		
			else 
			{
				pIndexBuffer++;
				continue;
			}
		}
		if(sscanf(CharTemp,"%lf",&dTemp) != SUCCESS) return 0;	
		pdTemp[i] = dTemp;
		pIndexBuffer++;
	}
	for(i = 0; i < ParametNum; i++)
		pdBuffe[i] = pdTemp[i];
	return 1;
}

void Debug_printf(void)
{
	static TIM_Delay  delay_stall;
	static u8 flag = 1;
	if(flag)
	{
		flag = 0;
		delay_TimInit(&delay_stall,Delay_40_ms,ENABLE);
	}
	else
	{
		if(delay_Tim(&delay_stall))
		{
			flag = 1;
			delay_TimInit(&delay_stall, Delay_40_ms,DISABLE);
			ReadMotorSTL();	
		}
	}
	
}


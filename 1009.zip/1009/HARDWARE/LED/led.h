#ifndef _LED_H
#define _LED_H
#include "sys.h"
/**************************************************
 * file		led.h
 * ver		V1.0
 * date		2022.07.20
***************************************************/


#define LED PAout(6)


void LED_Init(void);
#endif

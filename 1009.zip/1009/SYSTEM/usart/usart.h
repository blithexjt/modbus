#ifndef _USART_H
#define _USART_H
#include "sys.h"
#include "stdio.h"	


#define EN_USART1_RX 			1		//ʹ�ܣ�1��/��ֹ��0������1����
#define RXBUFFERSIZE   50 //�����С
#define Uart3Array_Len	5
#define Uart1Array_Len	5

extern UART_HandleTypeDef UART1_Handler; //UART���
extern UART_HandleTypeDef UART3_Handler; //UART���

extern DMA_HandleTypeDef  hdma_usart1_rx;
extern DMA_HandleTypeDef  hdma_usart3_rx;


typedef enum
{
	UartData_None = 0,
	UartData_Vaild,
}_eUartData_Sta;

typedef enum
{
	RX_Failed,
	RX_Success,
}RX_STA;

typedef struct
{
	u8 com1_rx_buffer[RXBUFFERSIZE];
	u16 com1_rx_len ;
	_eUartData_Sta DataSta; 
}UART1_Receive;

typedef struct
{
	u8 com3_rx_buffer[RXBUFFERSIZE];
	u16 com3_rx_len ;
	_eUartData_Sta DataSta; 
}UART3_Receive;


void usart1_init(u32 bound);
void usart3_init(u32 bound);

UART3_Receive* GetUart3Buffer(u8 revid);
UART1_Receive* GetUart1Buffer(u8 revid);

void USART3_SendString( u8 *DataString);

void USART_DMA_Init(void);
void MX_UART_IDLECpltCallback(UART_HandleTypeDef *huart);

#endif

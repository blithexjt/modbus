#include "usart.h"
#include "delay.h"
#include "ucommand.h"
#if 1
#pragma import(__use_no_semihosting)             
//��׼����Ҫ��֧�ֺ���                 
struct __FILE 
{ 
	int handle; 
}; 

FILE __stdout;       
//����_sys_exit()�Ա���ʹ�ð�����ģʽ    
void _sys_exit(int x) 
{ 
	x = x; 
} 
//�ض���fputc���� 
int fputc(int ch, FILE *f)
{ 	
	while((USART1->SR&0X40)==0);//ѭ������,ֱ���������   
	USART1->DR = (u8) ch;      
	return ch;
}
#endif 


 UART_HandleTypeDef UART1_Handler; //UART���
 UART_HandleTypeDef UART3_Handler; //UART���

 DMA_HandleTypeDef  hdma_usart1_rx;
 DMA_HandleTypeDef  hdma_usart3_rx;

UART1_Receive  uart1_rx;
static UART1_Receive uart1_data[Uart1Array_Len];

UART3_Receive  uart3_rx;
static UART3_Receive uart3_data[Uart3Array_Len];

void usart3_init(u32 bound)
{	
	
	//UART ��ʼ������
	UART3_Handler.Instance=USART3;					  
	UART3_Handler.Init.BaudRate=bound;				   
	UART3_Handler.Init.WordLength=UART_WORDLENGTH_8B;   //�ֳ�Ϊ8λ���ݸ�ʽ
	UART3_Handler.Init.StopBits=UART_STOPBITS_1;	    //һ��ֹͣλ
	UART3_Handler.Init.Parity=UART_PARITY_NONE;		    //����żУ��λ
	UART3_Handler.Init.HwFlowCtl=UART_HWCONTROL_NONE;   //��Ӳ������
	UART3_Handler.Init.Mode=UART_MODE_TX_RX;		    //�շ�ģʽ
	HAL_UART_Init(&UART3_Handler);					    //HAL_UART_Init()��ʹ��UART1
	
	__HAL_UART_ENABLE_IT(&UART3_Handler,UART_IT_RXNE);//�þ���Ҫ�ֶ�������cubeMX�����Զ�����;

  __HAL_UART_ENABLE_IT(&UART3_Handler,UART_IT_IDLE); //�þ���Ҫ�ֶ�������cubeMX�����Զ�����
  	HAL_UART_Receive_DMA(&UART3_Handler,(u8*) uart3_data[0].com3_rx_buffer, RXBUFFERSIZE);
}

void usart1_init(u32 bound)
{	
	
	//UART ��ʼ������
	UART1_Handler.Instance=USART1;					    //USART1
	UART1_Handler.Init.BaudRate=bound;				    //������
	UART1_Handler.Init.WordLength=UART_WORDLENGTH_8B;   //�ֳ�Ϊ8λ���ݸ�ʽ
	UART1_Handler.Init.StopBits=UART_STOPBITS_1;	    //һ��ֹͣλ
	UART1_Handler.Init.Parity=UART_PARITY_NONE;		    //����żУ��λ
	UART1_Handler.Init.HwFlowCtl=UART_HWCONTROL_NONE;   //��Ӳ������
	UART1_Handler.Init.Mode=UART_MODE_TX_RX;		    //�շ�ģʽ
	HAL_UART_Init(&UART1_Handler);					    //HAL_UART_Init()��ʹ��UART1
	
	__HAL_UART_ENABLE_IT(&UART1_Handler,UART_IT_RXNE);//�þ���Ҫ�ֶ�������cubeMX�����Զ�����;

    __HAL_UART_ENABLE_IT(&UART1_Handler,UART_IT_IDLE); //�þ���Ҫ�ֶ�������cubeMX�����Զ�����
    HAL_UART_Receive_DMA(&UART1_Handler,(u8*) (&uart1_data[0].com1_rx_buffer), RXBUFFERSIZE);

}

void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    //GPIO�˿�����
	GPIO_InitTypeDef GPIO_Initure;
	
	if(huart->Instance==USART1)//����Ǵ���1�����д���1 MSP��ʼ��
	{
	
		GPIO_Initure.Pin=GPIO_PIN_9;			//PA9
		GPIO_Initure.Mode=GPIO_MODE_AF_PP;		//�����������
		GPIO_Initure.Pull=GPIO_PULLUP;			//����
		GPIO_Initure.Speed=GPIO_SPEED_FAST;		//����
		GPIO_Initure.Alternate=GPIO_AF7_USART1;	//����ΪUSART1
		HAL_GPIO_Init(GPIOA,&GPIO_Initure);	   	//��ʼ��PA9

		GPIO_Initure.Pin=GPIO_PIN_10;			//PA10
		HAL_GPIO_Init(GPIOA,&GPIO_Initure);	   	//��ʼ��PA10
		
		GPIO_Initure.Pin = GPIO_PIN_8;
		GPIO_Initure.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_Initure.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOA,&GPIO_Initure);	   
		
		hdma_usart1_rx.Instance =  DMA2_Stream5;
		hdma_usart1_rx.Init.Channel = DMA_CHANNEL_4;
		hdma_usart1_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
		hdma_usart1_rx.Init.PeriphInc = DMA_PINC_DISABLE;
		hdma_usart1_rx.Init.MemInc = DMA_MINC_ENABLE;
		hdma_usart1_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
		hdma_usart1_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
		hdma_usart1_rx.Init.Mode = DMA_NORMAL;
		hdma_usart1_rx.Init.Priority = DMA_PRIORITY_LOW;
		HAL_DMA_Init(&hdma_usart1_rx);
	   
		__HAL_LINKDMA(&UART1_Handler,hdmarx,hdma_usart1_rx);
	}

	if(huart->Instance==USART3)
	{
	
		GPIO_Initure.Pin=GPIO_PIN_8;		
		GPIO_Initure.Mode=GPIO_MODE_AF_PP;		//�����������
		GPIO_Initure.Pull=GPIO_PULLUP;			//����
		GPIO_Initure.Speed=GPIO_SPEED_FAST;		//����
		GPIO_Initure.Alternate=GPIO_AF7_USART3;	//����ΪUSART3
		HAL_GPIO_Init(GPIOD,&GPIO_Initure);	   	

		GPIO_Initure.Pin=GPIO_PIN_9;			
		HAL_GPIO_Init(GPIOD,&GPIO_Initure);	   	
		
		GPIO_Initure.Pin = GPIO_PIN_10;
		GPIO_Initure.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_Initure.Pull = GPIO_PULLUP;
        HAL_GPIO_Init(GPIOD,&GPIO_Initure);	   
		
		hdma_usart3_rx.Instance =  DMA1_Stream1;
		hdma_usart3_rx.Init.Channel = DMA_CHANNEL_4;
		hdma_usart3_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
		hdma_usart3_rx.Init.PeriphInc = DMA_PINC_DISABLE;
		hdma_usart3_rx.Init.MemInc = DMA_MINC_ENABLE;
		hdma_usart3_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
		hdma_usart3_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
		hdma_usart3_rx.Init.Mode = DMA_NORMAL;
		hdma_usart3_rx.Init.Priority = DMA_PRIORITY_LOW;
		HAL_DMA_Init(&hdma_usart3_rx);
	   
		__HAL_LINKDMA(&UART3_Handler,hdmarx,hdma_usart3_rx);
	}
}


void USART_DMA_Init()
{
	HAL_NVIC_SetPriority(USART1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
	
	HAL_NVIC_SetPriority(USART3_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART3_IRQn);
}

void MX_UART_IDLECpltCallback(UART_HandleTypeDef *huart)
{
	volatile u8 Len = 0;
	static u8 rcv_id = 0;
	if(huart->Instance==USART3)
	{
		if(__HAL_UART_GET_FLAG(&UART3_Handler, UART_FLAG_IDLE) != RESET)
		{
			 __HAL_UART_CLEAR_IDLEFLAG(&UART3_Handler); 
			HAL_UART_DMAStop(&UART3_Handler);
			 uart3_data[rcv_id].com3_rx_len = RXBUFFERSIZE - __HAL_DMA_GET_COUNTER(&hdma_usart3_rx);
			uart3_data[rcv_id].DataSta = UartData_Vaild;
			rcv_id++;
			if(rcv_id >= Uart3Array_Len)
				rcv_id = 0;
			
			HAL_UART_Receive_DMA(&UART3_Handler, uart3_data[rcv_id].com3_rx_buffer, RXBUFFERSIZE);
		}
	
	}
	else if(huart->Instance==USART1)
	{
		if(__HAL_UART_GET_FLAG(&UART1_Handler, UART_FLAG_IDLE) != RESET)
		{
			 __HAL_UART_CLEAR_IDLEFLAG(&UART1_Handler);			
			HAL_UART_DMAStop(&UART1_Handler);
			 uart1_data[rcv_id].com1_rx_len = RXBUFFERSIZE - __HAL_DMA_GET_COUNTER(&hdma_usart1_rx);
			uart1_data[rcv_id].DataSta = UartData_Vaild;
			rcv_id++;
			if(rcv_id >= Uart1Array_Len)
				rcv_id = 0;			
			HAL_UART_Receive_DMA(&UART1_Handler,uart1_data[rcv_id].com1_rx_buffer, RXBUFFERSIZE);
		}
	}
}

void USART3_Receive_En(u8 rev_en)
{
	if(rev_en)
		HAL_GPIO_WritePin( GPIOD, GPIO_PIN_10,GPIO_PIN_RESET);
	else
		HAL_GPIO_WritePin(GPIOD,  GPIO_PIN_10,GPIO_PIN_SET);
}
void USART1_Receive_En(u8 rev_en)
{
	if(rev_en)
		HAL_GPIO_WritePin(GPIOA,  GPIO_PIN_8,GPIO_PIN_RESET);
	else
		HAL_GPIO_WritePin(GPIOA,  GPIO_PIN_8,GPIO_PIN_SET);
}

void USART3_SendString( u8 *DataString)
{
	int i =0;
	while(DataString[i] != '\0')
	{
		while((USART3->SR&0X40)==0);
		USART3->DR = (u8) DataString[i++]; 
	}
}

UART1_Receive* GetUart1Buffer(u8 revid)
{
	return &uart1_data[revid];
}

UART3_Receive* GetUart3Buffer(u8 revid)
{
	return &uart3_data[revid];
}



//����1�жϷ������
void USART1_IRQHandler(void)                	
{ 

	MX_UART_IDLECpltCallback(&UART1_Handler);
	
	HAL_UART_IRQHandler(&UART1_Handler);	//����HAL���жϴ������ú���

} 

void USART3_IRQHandler(void)                	
{ 

	MX_UART_IDLECpltCallback(&UART3_Handler);
	
	HAL_UART_IRQHandler(&UART3_Handler);	//����HAL���жϴ������ú���
}







